<?php

 
 echo "
 <div id=\"pane2\">
  <table class=\"header\">";
$tabIndex = 2000;
include ("conditions/pmtct.php");
echo "
  </table>
 </div>";


?>
