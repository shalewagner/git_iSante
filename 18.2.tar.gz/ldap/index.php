<?php
/**
 * Default index page
 *
 * This just redirects to the list script.
 *
 * @author	Svend Sorensen
 * @version	$Id: index.php 49 2006-04-21 00:16:50Z svends $
 */

// Redirect to list page
header('Location: list.php');
?>
