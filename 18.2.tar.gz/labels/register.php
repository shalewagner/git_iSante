<?php
$addrSection_1 = array (
   "en" => array (
	"",
	"Commune",
	""),
   "fr" => array (
	"",
	"Commune",
	"")
);
$occupation_1 = array (
   "en" => array (
	"",
	"Occupation of patient",
	""),
   "fr" => array (
	"",
	"Profession du patient",
	"")
);
?>