<?php


echo "
  <table class=\"header\">
   <tr>
    <td class=\"w_header\">" . $nurseSection[$version][$lang][2] . "</td>
   </tr>
   <tr>
    <td class=\"under_header\"></td>
   </tr>
  </table>
";
?>
