<?php

echo "
  <table class=\"header\">
   <tr>
    <td class=\"w_header\">" . $doctorSection[$lang][1] . "</td>
   </tr>
   <tr>
    <td class=\"under_header\">
    </td></tr>
  </table>
";
?>
