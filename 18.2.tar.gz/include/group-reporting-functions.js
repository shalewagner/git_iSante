$(document).ready(function () {

  // Get language from filter button on initial load
  var checkLanguage = $("#filterSubmit").attr("data-language");
  
  /*** Options for Datatables ***/
  // Defaults for TableTool export options  
  TableTools.DEFAULTS.aButtons = [ 
    "xls",
    "pdf",
    // FIXME  - Not localized
    { "sExtends": "copy", "sButtonText": "Copier", 
      "fnComplete" : function(nButton, oConfig, flash, text) {
        var
          lines = text.split('\n').length,
          len = this.s.dt.nTFoot === null ? lines-1 : lines-2,
          plural = (len==1) ? "" : "s";
        this.fnInfo( '<div class="alert alert-info" style="margin-top: 20px"><h6>Copié dans le presse-papiers.</h6>'+
          '<p>'+len+' ligne'+plural+' copié dans le Presse-papiers.</p></div>',
          2500
        );
      }
    }  
  ];
  TableTools.DEFAULTS.sSwfPath = [
    "include/copy_csv_xls_pdf.swf"
  ];
  
  // Datatable customizations (based on OpenELIS work)
  // Converts dates from our display format ( dd/mm/yyyy ) to
  // a sortable order
  jQuery.extend( jQuery.fn.dataTableExt.oSort, {
    "date-uk-pre": function ( a ) {
        var ukDatea = a.split('/');
        // Handles unknown dates for proper sort
        if (ukDatea[0] == 'XX' || ukDatea[0] == 'xx') {
          ukDatea[0] = '01';
        }
        if (ukDatea[1] == 'XX' || ukDatea[1] == 'xx') {
          ukDatea[1] = '01';
        }
        if (ukDatea[2] == 'XXXX' || ukDatea[2] == 'xxxx') {
          ukDatea[1] = '1000';
        }
        return (ukDatea[2] + ukDatea[1] + ukDatea[0]) * 1;
    },
    "date-uk-asc": function ( a, b ) {
        return ((a < b) ? -1 : ((a > b) ? 1 : 0));
    },
    "date-uk-desc": function ( a, b ) {
        return ((a < b) ? 1 : ((a > b) ? -1 : 0));
    }
  });
  /* Set the defaults for DataTables initialisation */
  $.extend( true, $.fn.dataTable.defaults, {
    "sDom": "<'row-fluid'<'span3'l><'span4'T><'span5'f>r>t<'row-fluid'<'span6'i><'span6'p>>",
    "sPaginationType": "bootstrap",
    "oLanguage": {
        // FIXME - Not localized
        "sLengthMenu": "Afficher _MENU_ ",
        "sSearch": "Filtrer : ",
        "sInfoFiltered": "(filtrée à partir de _MAX_)",
        "sInfoEmpty": " ",
        "sInfo": " _START_ à _END_ de _TOTAL_",
        "sZeroRecords": "Aucun patient correspondant n'a été trouvé.",
        "sEmptyTable": "Aucun patient correspondant n'a été trouvé.",
        "oPaginate": {
          "sPrevious": " ",
          "sNext": " "
        }
    }
  });
  /* Default class modification */
  $.extend( $.fn.dataTableExt.oStdClasses, {
    "sWrapper": "dataTables_wrapper form-inline"
  });
  /* API method to get paging information */
  $.fn.dataTableExt.oApi.fnPagingInfo = function ( oSettings ) {
    return {
      "iStart":         oSettings._iDisplayStart,
      "iEnd":           oSettings.fnDisplayEnd(),
      "iLength":        oSettings._iDisplayLength,
      "iTotal":         oSettings.fnRecordsTotal(),
      "iFilteredTotal": oSettings.fnRecordsDisplay(),
      "iPage":          oSettings._iDisplayLength === -1 ?
        0 : Math.ceil( oSettings._iDisplayStart / oSettings._iDisplayLength ),
      "iTotalPages":    oSettings._iDisplayLength === -1 ?
        0 : Math.ceil( oSettings.fnRecordsDisplay() / oSettings._iDisplayLength )
    };
  };
  /* Bootstrap style pagination control */
  $.extend( $.fn.dataTableExt.oPagination, {
    "bootstrap": {
      "fnInit": function( oSettings, nPaging, fnDraw ) {
        var oLang = oSettings.oLanguage.oPaginate;
        var fnClickHandler = function ( e ) {
          e.preventDefault();
          if ( oSettings.oApi._fnPageChange(oSettings, e.data.action) ) {
            fnDraw( oSettings );
          }
        };
        $(nPaging).addClass('pagination').append(
          '<ul>'+
            '<li class="prev disabled"><a href="#">&larr; '+oLang.sPrevious+'</a></li>'+
            '<li class="next disabled"><a href="#">'+oLang.sNext+' &rarr; </a></li>'+
          '</ul>'
        );
        var els = $('a', nPaging);
        $(els[0]).bind( 'click.DT', { action: "previous" }, fnClickHandler );
        $(els[1]).bind( 'click.DT', { action: "next" }, fnClickHandler );
      },
      "fnUpdate": function ( oSettings, fnDraw ) {
        var iListLength = 5;
        var oPaging = oSettings.oInstance.fnPagingInfo();
        var an = oSettings.aanFeatures.p;
        var i, ien, j, sClass, iStart, iEnd, iHalf=Math.floor(iListLength/2);
        if ( oPaging.iTotalPages < iListLength) {
          iStart = 1;
          iEnd = oPaging.iTotalPages;
        }
        else if ( oPaging.iPage <= iHalf ) {
          iStart = 1;
          iEnd = iListLength;
        } else if ( oPaging.iPage >= (oPaging.iTotalPages-iHalf) ) {
          iStart = oPaging.iTotalPages - iListLength + 1;
          iEnd = oPaging.iTotalPages;
        } else {
          iStart = oPaging.iPage - iHalf + 1;
          iEnd = iStart + iListLength - 1;
        }
        for ( i=0, ien=an.length ; i<ien ; i++ ) {
          // Remove the middle elements
          $('li:gt(0)', an[i]).filter(':not(:last)').remove();
          // Add the new list items and their event handlers
          for ( j=iStart ; j<=iEnd ; j++ ) {
            sClass = (j==oPaging.iPage+1) ? 'class="active"' : '';
            $('<li '+sClass+'><a href="#">'+j+'</a></li>')
              .insertBefore( $('li:last', an[i])[0] )
              .bind('click', function (e) {
                e.preventDefault();
                oSettings._iDisplayStart = (parseInt($('a', this).text(),10)-1) * oPaging.iLength;
                fnDraw( oSettings );
              } );
          }
          // Add / remove disabled classes from the static elements
          if ( oPaging.iPage === 0 ) {
            $('li:first', an[i]).addClass('disabled');
          } else {
            $('li:first', an[i]).removeClass('disabled');
          }

          if ( oPaging.iPage === oPaging.iTotalPages-1 || oPaging.iTotalPages === 0 ) {
            $('li:last', an[i]).addClass('disabled');
          } else {
            $('li:last', an[i]).removeClass('disabled');
          }
        }
      }
    }
  });
  /*
   * TableTools Bootstrap compatibility
   * Required TableTools 2.1+
   */
  if ( $.fn.DataTable.TableTools ) {
    // Set the classes that TableTools uses to something suitable for Bootstrap
    $.extend( true, $.fn.DataTable.TableTools.classes, {
      "container": "DTTT btn-group",
      "buttons": {
        "normal": "btn btn-mini",
        "disabled": "disabled"
      },
      "collection": {
        "container": "DTTT_dropdown dropdown-menu",
        "buttons": {
          "normal": "",
          "disabled": "disabled"
        }
      },
      "print": {
        "info": "DTTT_print_info modal"
      },
      "select": {
        "row": "active"
      }
    });

    // Have the collection use a bootstrap compatible dropdown
    $.extend( true, $.fn.DataTable.TableTools.DEFAULTS.oTags, {
      "collection": {
        "container": "ul",
        "button": "li",
        "liner": "a"
      }
    });
  }
  
  /*** End Datatables options ***/

  fillInTable();
  arrangeSubRows();
  loadAndDisplay();
  
  // Shows the report table after data loads
  function loadAndDisplay() {
    $("#hideBox").delay(800).fadeOut('fast', function() {
      $("#resultsByTime").show();
    });
  }

  // Shows the patient table in modal after data loads
  function loadAndDisplayPatients() {
    $("#hideBoxPatients").delay(1000).fadeOut('fast', function() {
      var oTable = $('#patientTable').dataTable({
        // Options for proper display, sorting with datatables
        "aoColumnDefs": [
          { "aTargets": [0], "sType": "html" },
          { "aTargets": [4], "sType": "date-uk" }
        ],
        // FIXME - "Tous" not localized
        "aLengthMenu": [[10, 100 , -1], [10, 100, "Tous"]],
        // Empty sorting means we let sql output handle the sorting
        aaSorting: []
      });
      $("#patientOutput").removeClass('invisible');
    });
  }

  // Add view toggles and links to each row
  function fillInTable() {
    var toggleIcon = ' <i class="view-toggle icon-chevron-down icon-blue"></i>';
    var rowLinks = '<div class="pull-right"><a href="javascript:;" class="patient-launch" title="View Patient List"><i class="icon-list report-icon"></i></a></div>';
    // Not currenlty in use - for tables with only one set of numbers per row (doesn't display chart link
    //var rowLinksShort = '<div class="pull-right"><a href="#" class="patient-launch" title="View Patient List"><i class="icon-list report-icon"></i></a></div>';
    var total = 0;
    $(".report-mainrow").each(function() {
      rowtotal = $(this).closest('tr').find('td:last-child').prev().html();
      total = (total * 1) + (rowtotal * 1);
      var rowCount = $(this).nextUntil('.report-mainrow,.report-totalrow').length;
      if ( rowCount > '0') {
        $(this).find('td.report-row-info span').append(toggleIcon);
        $(this).find('td:first-child').addClass('view-details');
        $(this).children('td').eq(1).find('div').addClass('view-details');
      }
    });
    $('.report-table tbody td.report-row-info div').each(function() {
      $(this).before(rowLinks);
    });
    // For displaying one set of results only
    $('.report-table tbody td.report-row-info-short div').each(function() {
      $(this).before(rowLinksShort);
    });
    // Add total to total row
    $("#datatable tr:last").find('td:last-child').prev().empty().append(total);
  };

  // Add correct rowspan for subrows and add chart link
  // FIXME - Should probably display the chart icon some other way rather than
  // relying on the client to redo.
  function arrangeSubRows() {
    $(".report-mainrow").each(function() {
      var rowCount = $(this).nextUntil('.report-mainrow,.report-totalrow').length;
      var multiChart = "<td class='subrows-chart' rowspan='" + rowCount +"'></td>";
      var tooManyRows = "<td class='subrows-chart' rowspan='" + rowCount +"'></td>";
      // Shows link to chart if # of rows is between 1 and 6. This could be tweaked
      // particularly if the graph space is made larger, but two main series make
      // for an ugly chart.
      if (rowCount == '1') {
        $(this).next('tr').prepend("<td class='subrows-chart'></td>");
      } else if ( rowCount > '1' && rowCount < '7' ) {
        $(this).next('tr').prepend(multiChart);
      } else if ( rowCount >= '7' ) {
        $(this).next('tr').prepend(tooManyRows);
      }
    });
  }

  // Use toggle to view subrows
  $("#contentArea").on('click', '.view-details', (function() {
    $(this).parents('tr').toggleClass('report-row-open').nextUntil('.report-mainrow,.report-totalrow').toggle();
    $(this).parents('tr').find('.view-toggle').toggleClass('icon-chevron-down').toggleClass('icon-chevron-up').toggleClass('icon-gray');
  }));

  // Patient modal open. Uses $.post to query database
  $("#contentArea").on('click', '.patient-launch', (function() {
    //$("#patientOutput").empty();
    var type = $(this).closest('tr').attr('class');
    var sitecode = $(this).closest('tr').attr('sitecode');
    var orgname = $(this).closest('tr').attr("orgname");
    var orgunit = $(this).closest('tr').attr("orgunit");
    var tblname = $("#datatable").attr('tblname');
    var olevel = $("#datatable").attr('olevel');
    var olevelval = $(this).closest('tr').attr("olevelval");
    $.post('group-reports-patients.php', { lang: checkLanguage, type: type, sitecode: sitecode, orgname: orgname, orgunit: orgunit, tblname: tblname, olevel: olevel, olevelval:olevelval }, function(data) {
      $("#patientOutput").html(data);
      loadAndDisplayPatients();
    });
    // FIXME - Grabs percentages as well as actual counts. Should only grab counts
    var patientCount = $(this).closest('tr').find('td:last-child').prev().html();  
    if (type == 'report-subrow') {
      var graphTitleParent = $(this).closest('tr').prevAll("tr.report-mainrow:first").attr("orgname");
      graphTitle = graphTitleParent + " - " + orgname;
    } else {
      graphTitle = orgname;
    }
    if (olevelval.length > 0) graphTitle += ' - ' + olevelval;
    // Update patient count and title in patient modal
    $("#patientCount").html(patientCount);
    $("#modalPatientsTitle").text(graphTitle);
    // Actually open modal window
    $("#modalPatients").modal();
  }));
  // Removes patient table when modal is closed. Prevents flashes of old list
  // when a new list is opened. Also, allow for display of the 'loading' graphic
  $('#modalPatients').on('hidden', function () {
    $('#patientOutput').empty().addClass('invisible');
    $("#hideBoxPatients").show();
    // Revert title back to original
    //$("title").text(pageTitleOriginal);
  })

  
});
