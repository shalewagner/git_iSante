<?
	require_once 'include/standardHeaderExt.php';
	require_once 'include/verticalTabHeader.php';
?>