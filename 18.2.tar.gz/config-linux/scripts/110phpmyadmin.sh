#!/bin/sh -vx

cp -f templates-output/phpmyadmin-config.inc.php /etc/phpmyadmin/config.inc.php
