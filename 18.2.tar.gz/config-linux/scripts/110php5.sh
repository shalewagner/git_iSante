#!/bin/sh -vx

cp -f templates-output/php5-itech.ini /etc/php5/apache2/conf.d/itech.ini
