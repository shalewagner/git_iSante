#!/bin/sh -vx

update-locale --reset LANG=fr_FR.UTF-8
