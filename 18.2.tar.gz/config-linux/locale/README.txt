
How to update locales:

1. Remove the ref.po file.
2. Run `make` in locales/
3. Copy any new untranslated strings from messages.po to def.po.
4. Add translations to the def.po file for new strings.
5. Run `make` in locales/ again. 
