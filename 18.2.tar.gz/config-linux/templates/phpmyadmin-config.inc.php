<?php

#################################
########## !WARNING! ############
#################################
#This file is created by setup-isante.pl and will be overwritten during upgrades of iSante.

$cfg['MaxExactCount'] = 1;
$cfg['LoginCookieValidity'] = 72000;
$cfg['OBGzip'] = false;

?>
