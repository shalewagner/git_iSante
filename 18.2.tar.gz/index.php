<?php 
require 'splash.php'; 
?>