Source: http://www.who.int/childgrowth/standards/en/

split-lhfa.sh can be used to split up files which contain both length and height data. This is currently not being done.

There are no LMS values for the weight-for-height in the detailed 1mm "wfh_*_p_exp.txt" files. They are available in the 5mm "tab_wfh_*_p_2_5.txt" files though so we'll use those instead. 
