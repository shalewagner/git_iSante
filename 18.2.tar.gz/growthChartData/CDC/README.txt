Source: http://www.cdc.gov/growthcharts/percentile_data_files.htm
