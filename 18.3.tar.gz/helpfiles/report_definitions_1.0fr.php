<TABLE WIDTH="930">
<TR>
<TD WIDTH="930">
<P ALIGN=CENTER STYLE="margin-bottom: 0in"><FONT COLOR="#000080"><FONT FACE="Arial, sans-serif"><FONT SIZE=6 STYLE="font-size: 22pt"><B>Rapport de d&eacute;finition EMR</B></FONT></FONT></FONT></P>
<P STYLE="font-family: Arial, sans-serif; font-size: 12pt; so-language: en-US; margin-bottom: 0in"><BR>
</P>
	<P STYLE="margin-top: 0.17in; page-break-after: avoid"><FONT COLOR="#000080"><FONT SIZE=4 STYLE="font-size: 16pt"><B><A NAME="1.0">1.0
	Table des mati&egrave;res</A></B></FONT></FONT></P>
	<P STYLE="margin-left: 0.08in; margin-right: 0.08in; margin-bottom: 0in; background: transparent">
	<SPAN STYLE="background: transparent"><A HREF="#1.0">1.0 Table des mati&egrave;res</A></SPAN></P>
	<P STYLE="margin-left: 0.08in; margin-right: 0.08in; margin-bottom: 0in; background: transparent">
	<SPAN STYLE="background: transparent"><A HREF="helpfile.php?file=report_definitions_2.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>&">2.0 R&eacute;sum&eacute;</A></SPAN></P>
	<P STYLE="margin-left: 0.08in; margin-right: 0.08in; margin-bottom: 0in; background: transparent">
	<SPAN STYLE="background: transparent"><A HREF="helpfile.php?file=report_definitions_3.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>&">3.0 Emplacement des rapports</A></SPAN></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_3.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#3.0.1">3.0.1 Tableau 1 : Liste des cat&eacute;gories de rapports</A></P>
	<P STYLE="margin-left: 0.08in; margin-right: 0.08in; margin-bottom: 0in; background: transparent">
	<SPAN STYLE="background: transparent"><A HREF="helpfile.php?file=report_definitions_4.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>&">4.0 Classification des patients par statut d&rsquo;activit&eacute;</A></SPAN></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_4.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#4.1">4.1 D&eacute;finitions importantes</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_4.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#4.1.1">4.1.1 Patients actifs sous ARV</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_4.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#4.1.2">4.1.2 Patients actifs sous soins palliatifs (non sous ARV)</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_4.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#4.1.4">4.1.3 Patients inactifs sous ARV</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_4.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#4.1.5">4.1.4 Patients inactifs sous soins palliatifs (non sous ARV)</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_4.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#4.1.9">4.1.5 Patients discontinu&eacute;s sous ARV</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_4.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#4.1.10">4.1.6 Patients discontinu&eacute;s sous soins palliatifs (non sous ARV)</A></P>
	<P STYLE="margin-left: 0.08in; margin-right: 0.08in; margin-bottom: 0in; background: transparent">
	<SPAN STYLE="background: transparent"><A HREF="helpfile.php?file=report_definitions_5.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>&">5.0 Page de param&egrave;tres de rapport</A></SPAN></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_5.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#5.0.1">5.0.1 Figure 1 : Page de param&egrave;tres de rapport&nbsp;:&nbsp;Test
        effectu&eacute;</A></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_5.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#5.1">5.1 D&eacute;finitions importantes</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_5.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#5.1.1">5.1.1 Dates de d&eacute;but/fin</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_5.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#5.1.2">5.1.2 Statut de patient</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_5.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#5.1.3">5.1.3 Niveau organisationnel</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_5.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#5.1.4">5.1.4 Statut du traitement</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_5.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#5.1.4.1">5.1.4.1 Sous  ARV</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_5.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#5.1.4.2">5.1.4.2 Sous soins palliatifs</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_5.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#5.1.4.3">5.1.4.3 Sous Prophylaxie &agrave; l&rsquo;INH</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_5.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#5.1.4.4">5.1.4.4 Sous Cotrimoxazole</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_5.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#5.1.4.5">5.1.4.5 Sous traitement TB</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_5.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#5.1.5">5.1.5 Groupement d&eacute;mographique</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_5.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#5.1.6">5.1.6 Type de tests</A></P>
	<P STYLE="margin-left: 0.08in; margin-right: 0.08in; margin-bottom: 0in; background: transparent">
	<SPAN STYLE="background: transparent"><A HREF="helpfile.php?file=report_definitions_6.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>&">6.0 Rapport de patients actifs et inactifs</A></SPAN></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_6.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#6.1">6.1 Utilisation</A></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_6.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#6.2">6.2 R&eacute;sultats</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_6.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#6.2.1">6.2.1 Figure 2 : En-t&ecirc;te de r&eacute;sultats pour le
        rapport&nbsp;:&nbsp;Patients actifs/inactifs</A></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_6.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#6.3">6.3 D&eacute;finitions importantes</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_6.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#6.3.1">6.3.1 No. de patient attribu&eacute; par le site</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_6.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#6.3.2">6.3.2 Num&eacute;ro d&rsquo;identit&eacute; nationale</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_6.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#6.3.3">6.3.3 Pr&eacute;nom</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_6.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#6.3.4">6.3.4 Nom</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_6.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#6.3.5">6.3.5 Sexe</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_6.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#6.3.6">6.3.6 &Acirc;ge</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_6.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#6.3.7">6.3.7 Statut</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_6.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#6.3.8">6.3.8 Derni&egrave;re date</A></P>
	<P STYLE="margin-left: 0.08in; margin-right: 0.08in; margin-bottom: 0in; background: transparent">
	<SPAN STYLE="background: transparent"><A HREF="helpfile.php?file=report_definitions_7.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>&">7.0 Qualit&eacute; des soins&nbsp;:&nbsp;Rappels de rendez-vous</A></SPAN></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_7.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#7.1">7.1 Utilisation</A></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_7.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#7.2">7.2 R&eacute;sultats</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_7.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#7.2.1">7.2.1 Figure 3 : En-t&ecirc;te de r&eacute;sultats pour le
        rapport&nbsp;:&nbsp;Visite clinique planifi&eacute;e dans les 7 jours &agrave;
        venir</A></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_7.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#7.3">7.3 D&eacute;finitions importantes</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_7.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#7.3.1">7.3.1 Statut de Patient</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_7.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#7.3.2">7.3.2 Prochaine date de visite</A></P>
	<P STYLE="margin-left: 0.08in; margin-right: 0.08in; margin-bottom: 0in; background: transparent">
	<SPAN STYLE="background: transparent"><A HREF="helpfile.php?file=report_definitions_8.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>&">8.0 Qualit&eacute; des soins&nbsp;:&nbsp;Rappels d'analyses de laboratoire</A></SPAN></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_8.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#8.1">8.1 Utilisation</A></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_8.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#8.2">8.2 R&eacute;sultats</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_8.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#8.2.1">8.2.1 Figure 4 : En-t&ecirc;te de r&eacute;sultats pour le
        rapport&nbsp;:&nbsp;Test effectu&eacute;</A></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_8.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#8.3">8.3 D&eacute;finitions importantes</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_8.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#8.3.1">8.3.1 Test jamais effectu&eacute;</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_8.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#8.3.2">8.3.2 Test effectu&eacute;</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_8.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#8.3.3">8.3.3 Test n&eacute;cessaire sous 30 jours</A></P>
	<P STYLE="margin-left: 0.08in; margin-right: 0.08in; margin-bottom: 0in; background: transparent">
	<SPAN STYLE="background: transparent"><A HREF="helpfile.php?file=report_definitions_9.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>&">9.0 Qualit&eacute; des soins&nbsp;:&nbsp;Rappels de soins n&eacute;ssaires</A></SPAN></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_9.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#9.1">9.1 M&eacute;dicalement &eacute;ligibles aux ARV mais non enr&ocirc;l&eacute;s</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_9.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#9.1.1">9.1.1 Utilisation</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_9.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#9.1.2">9.1.2 R&eacute;sultats</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_9.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#9.1.2.1">9.1.2.1 Figure 5 :  En-t&ecirc;te de r&eacute;sultats pour le
        rapport&nbsp;:&nbsp;M&eacute;dicalement &eacute;ligibles aux ARV mais
        non enrol&eacute;s</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_9.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#9.1.3">9.1.3 D&eacute;finitions importantes</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_9.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#9.1.3.1">9.1.3.1 Raison d&rsquo;&eacute;l&eacute;gibilit&eacute;</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_9.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#9.1.3.2">9.1.3.2 Non enr&ocirc;l&eacute;</A></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_9.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#9.2">9.2 Prophylaxie de Cotrimoxizole adapt&eacute;e pour ceux qui pr&eacute;sentent des risques</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_9.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#9.2.1">9.2.1 Utilisation</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_9.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#9.2.2">9.2.2 R&eacute;sultats</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_9.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#9.2.2.1">9.2.2.1 Figure 6 : En-t&ecirc;te de r&eacute;sultats pour le
        rapport&nbsp;:&nbsp;Prophylaxie de Cotrimoxizole adapt&eacute;e pour ceux qui
         pr&eacute;sentent des risques.</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_9.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#9.2.3">9.2.3 D&eacute;finitions importantes</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_9.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#9.2.3.1">9.2.3.1 Raison d&rsquo;&eacute;l&eacute;gibilit&eacute;</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_9.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#9.2.3.2">9.2.3.2 Th&eacute;rapie &agrave; la Cotrimoxazole adapt&eacute;e</A></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_9.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#9.3">9.3 Cotrimoxazole d&eacute;marr&eacute;e, puis discontinu&eacute;e</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_9.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#9.3.1">9.3.1 Utilisation</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_9.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#9.3.2">9.3.2 R&eacute;sultats</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_9.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#9.3.2.1">9.3.2.1 Figure 7 : En-t&ecirc;te de r&eacute;sultats pour le
        rapport&nbsp;:&nbsp;Cotrimoxazole d&eacute;marr&eacute;e, puis
        discontinu&eacute;e</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_9.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#9.3.3">9.3.3 D&eacute;finitions importantes</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_9.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#9.3.3.1">9.3.3.1 Cotrimoxazole d&eacute;marr&eacute;e</A></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_9.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#9.4">9.4 R&eacute;sultats d'analyses anormaux</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_9.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#9.4.1">9.4.1 Utilisation</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_9.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#9.4.2">9.4.2 R&eacute;sultats</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_9.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#9.4.2.1">9.4.2.1 Figure 8 : En-t&ecirc;te de r&eacute;sultats de CD4 pour le
        rapport&nbsp;:&nbsp;R&eacute;sultats d'analyses anormaux</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_9.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#9.4.3">9.4.3 D&eacute;finitions importantes</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_9.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#9.4.3.1">9.4.3.1 R&eacute;sultat de test anormal</A></P>
	<P STYLE="margin-left: 0.08in; margin-right: 0.08in; margin-bottom: 0in; background: transparent">
	<SPAN STYLE="background: transparent"><A HREF="helpfile.php?file=report_definitions_10.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>&">10.0 Qualit&eacute; des soins&nbsp;:&nbsp;&Eacute;ligible pour un
        traitement TB mais non d&eacute;marr&eacute;</A></SPAN></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_10.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#10.1">10.1 Utilisation</A></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_10.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#10.2">10.2 R&eacute;sultats</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_10.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#10.2.1">10.2.1 Figure 9 : En-t&ecirc;te de r&eacute;sultats pour le
        rapport&nbsp;:&nbsp;Patients avec signes et sympt&ocirc;mes sugg&eacute;rant
        la TB, mais sans analyse des crachats ou radiographie pulmonaires</A></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_10.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#10.3">10.3 D&eacute;finitions importantes</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_10.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#10.3.1">10.3.1 Signes et sympt&ocirc;mes &eacute;vocateurs de TB</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_10.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#10.3.2">10.3.2 Pas de crachat ou de radiographie du thoracique</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_10.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#10.3.3">10.3.3 Patients avec un crachat ou un r&eacute;sultat de radiographie
        pulmonaire anormal</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_10.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#10.3.4">10.3.4 Aucun diagnostic TB &eacute;tabli</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_10.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#10.3.5">10.3.5 Patients avec un diagnostic de TB</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_10.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#10.3.6">10.3.6 Pas de traitement</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_10.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#10.3.7">10.3.7 Patients ayant compl&eacute;t&eacute; le traitement TB</A></P>
	<P STYLE="margin-left: 0.08in; margin-right: 0.08in; margin-bottom: 0in; background: transparent">
	<SPAN STYLE="background: transparent"><A HREF="helpfile.php?file=report_definitions_11.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>&">11.0 Qualit&eacute; des soins&nbsp;:&nbsp;Les r&eacute;gimes et discontinuation de m&eacute;dicaments</A></SPAN></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_11.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#11.1">11.1 Patients sous r&eacute;gime de premi&egrave;re ou deuxi&egrave;me
        ligne</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_11.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#11.1.1">11.1.1 Utilisation</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_11.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#11.1.2">11.1.2 R&eacute;sultats</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_11.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#11.1.2.1">11.1.2.1 Figure 10 : En-t&ecirc;te de r&eacute;sultats pour le
        rapport&nbsp;:&nbsp;Patients sous r&eacute;gimes de premi&egrave;re
        ou deuxi&egrave;me ligne</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_11.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#11.1.3">11.1.3 D&eacute;finitions importantes</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_11.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#11.1.3.1">11.1.3.1 R&eacute;gime</A></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_11.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#11.2">11.2 Substitution de m&eacute;dicament et changement de r&eacute;gime</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_11.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#11.2.1">11.2.1 Utilisation</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_11.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#11.2.2">11.2.2 R&eacute;sultats</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_11.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#11.2.2.1">11.2.2.1 Figure 11 : En-t&ecirc;te de r&eacute;sultats pour le
        rapport&nbsp;:&nbsp;Patients ayant b&eacute;n&eacute;fici&eacute; d'une substitution d'une mol&eacute;cule d'ARV</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_11.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#11.2.3">11.2.3 D&eacute;finitions importantes</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_11.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#11.2.3.1">11.2.3.1 Date de changement</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_11.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#11.2.3.2">11.2.3.2 R&eacute;gime</A></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_11.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#11.3">11.3 Discontinuation de m&eacute;dicaments</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_11.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#11.3.1">11.3.1 Utilisation</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_11.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#11.3.2">11.3.2 R&eacute;sultats</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_11.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#11.3.2.1">11.3.2.1 Figure 12 : En-t&ecirc;te de r&eacute;sultats pour le
        rapport&nbsp;:&nbsp;Discontinuation de m&eacute;dicaments</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_11.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#11.3.3">11.3.3 D&eacute;finitions importantes</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_11.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#11.3.3.1">11.3.3.1 Nom de m&eacute;dicament</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_11.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#11.3.3.2">11.3.3.2 Raison de discontinuation</A></P>
	<P STYLE="margin-left: 0.08in; margin-right: 0.08in; margin-bottom: 0in; background: transparent">
	<SPAN STYLE="background: transparent"><A HREF="helpfile.php?file=report_definitions_12.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>&">12.0 Qualit&eacute; des soins&nbsp;:&nbsp;Indicateurs d'analyses de laboratoires n&eacute;cessaires</A></SPAN></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_12.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#12.1">12.1 Utilisation</A></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_12.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#12.2">12.2 R&eacute;sultats</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_12.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#12.2.1">12.2.1 Figure 13 : En-t&ecirc;te de r&eacute;sultats pour le rapport&nbsp;:&nbsp;Test effectu&eacute;</A></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_12.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#12.3">12.3 D&eacute;finitions importantes</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_12.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#12.3.1">12.3.1 P&eacute;riode de temps</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_12.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#12.3.2">12.3.2 Num&eacute;rateur</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_12.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#12.3.3">12.3.3 D&eacute;nominateur</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_12.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#12.3.4">12.3.4 Pourcentage</A></P>
	<P STYLE="margin-left: 0.08in; margin-right: 0.08in; margin-bottom: 0in; background: transparent">
	<SPAN STYLE="background: transparent"><A HREF="helpfile.php?file=report_definitions_13.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>&">13.0 Qualit&eacute; des soins&nbsp;:&nbsp;Indicateurs des soins n&eacute;cessaires</A></SPAN></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_13.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#13.1">13.1 Utilisation</A></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_13.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#13.2">13.2 R&eacute;sultats</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_13.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#13.2.1">13.2.1 Figure 14 : En-t&ecirc;te de r&eacute;sultats pour le rapport&nbsp;:&nbsp;Enr&ocirc;lement aux ARV parmi les patients m&eacute;dicalement &eacute;ligibles</A></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_13.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#13.3">13.3 D&eacute;finitions importantes</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_13.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#13.3.1">13.3.1 Num&eacute;rateur</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_13.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#13.3.2">13.3.2 D&eacute;nominateur</A></P>
	<P STYLE="margin-left: 0.08in; margin-right: 0.08in; margin-bottom: 0in; background: transparent">
	<SPAN STYLE="background: transparent"><A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>&">14.0 Gestion de programmes&nbsp;:&nbsp;Rapports par &eacute;tablissement</A></SPAN></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.1">14.1 Rapport mensuel PEPFAR/OMS par &eacute;tablissement</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.1.1">14.1.1 Utilisation</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.1.2">14.1.2 R&eacute;sultats</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.1.2.1">14.1.2.1 Figure 15 : Extrait du rapport mensuel d&rsquo;&eacute;tablissement PEPFAR/OMS, pour l&rsquo;H&ocirc;pital St. Michel, Fevrier-08</A></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.2">14.2 Surveillance de cas VIH</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.2.1">14.2.1 Utilisation</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.2.2">14.2.2 R&eacute;sultats</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.2.2.1">14.2.2.1 Figure 16 : En-t&ecirc;te de r&eacute;sultats pour le rapport&nbsp;:&nbsp;Surveillance de cas VIH</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.2.3">14.2.3 D&eacute;finitions importantes</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.2.3.1">14.2.3.1 Code d&rsquo;&eacute;tablissement</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.2.3.2">14.2.3.2 &Eacute;l&eacute;ment de donn&eacute;es</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.2.3.3">14.2.3.3 Nom de champ</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.2.3.4">14.2.3.4 Valeur</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.2.3.5">14.2.3.5 Date de visite</A></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in; background: transparent">
	<SPAN STYLE="background: transparent"><A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.3">14.3 Rapport HEALTHQUAL</A></SPAN></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.3.1">14.3.1 Utilisation</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.3.2">14.3.2 R&eacute;sultats</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.3.2.1">14.3.2.1 Figure 17 : Exemple d&rsquo;extrait de rapport &laquo;&nbsp;HEALTHQUAL&nbsp;&raquo;</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.3.2.1">14.3.2.2 Figure 18 : Exemple de graphique de rapport &laquo;&nbsp;HEALTHQUAL&nbsp;&raquo;</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.3.3">14.3.3 D&eacute;finitions importantes</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.3.3.1">14.3.3.1 Patients actifs</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.3.3.2">14.3.3.2 R&eacute;tention des patients en prise en charge ARV</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.3.3.3">14.3.3.3 R&eacute;tention des patients en prise en charge clinique</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.3.3.4">14.3.3.4 CD4</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.3.3.5">14.3.3.5 CD4 &agrave; l'enr&ocirc;lement</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.3.3.6">14.3.3.6 Enr&ocirc;lement ARV</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.3.3.7">14.3.3.7 Prophylaxie au Cotrimoxazole</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.3.3.8">14.3.3.8 &Eacute;valuation de l'adh&eacute;rence</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.3.3.9">14.3.3.9 Niveau d'adh&eacute;rence</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.3.3.10">14.3.3.10 D&eacute;pistage de la TB</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.3.3.11">14.3.3.11 Prophylaxie &agrave; l'INH</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.3.3.12">14.3.3.12 &Eacute;valuation nutritionnelle</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.3.3.13">14.3.3.13 Surveillance de la malnutrition s&eacute;v&egrave;re</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.3.3.14">14.3.3.14 Planification familiale</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.3.3.15">14.3.3.15 PTME</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.3.3.16">14.3.3.16 Traitement de la syphilis</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.3.3.17">14.3.3.17 D&eacute;pistage du cancer du col de l'ut&eacute;rus</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.3.3.18">14.3.3.18 &Eacute;valuation de la sant&eacute; mentale</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.3.3.19">14.3.3.19 Immunisation p&eacute;diatrique</A></P>
	<P STYLE="margin-left: 0.72in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.3.3.19.1">14.3.3.19.1 Tableau 2: Calendrier de vaccinations p&eacute;diatriques recommand&eacute; en usage avant le 30-juin-2009</A></P>
	<P STYLE="margin-left: 0.72in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.3.3.19.2">14.3.3.19.2 Tableau 3: Calendrier de vaccinations p&eacute;diatriques recommand&eacute; en usage apr&egrave;s le 30-juin-2009</A></P>
	<P STYLE="margin-left: 0.6in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_14.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#14.3.3.20">14.3.3.20 D&eacute;tection pr&eacute;coce du VIH p&eacute;diatrique</A></P>
	<P STYLE="margin-left: 0.08in; margin-right: 0.08in; margin-bottom: 0in; background: transparent">
	<SPAN STYLE="background: transparent"><A HREF="helpfile.php?file=report_definitions_15.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>&">15.0 Gestion de programme&nbsp;:&nbsp;D&eacute;mographie des patients</A></SPAN></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_15.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#15.1">15.1 Utilisation</A></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_15.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#15.2">15.2 R&eacute;sultats</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_15.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#15.2.1">15.2.1 Figure 19 : Exemple de rapport&nbsp;:&nbsp;&Acirg;ge &agrave; la premi&egrave;re visite</A></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_15.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#15.3">15.3 D&eacute;finitions importantes</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_15.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#15.3.1">15.3.1 Nombre de patients</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_15.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#15.3.2">15.3.2 Patients par groupe d&rsquo;&acirc;ge</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_15.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#15.3.3">15.3.3 &Acirc;ge &agrave; la premi&egrave;re visite</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_15.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#15.3.4">15.3.4 Nombre de patients par sexe</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_15.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#15.3.5">15.3.5 Facteurs de risque de transmission du VIH</A></P>
	<P STYLE="margin-left: 0.08in; margin-right: 0.08in; margin-bottom: 0in; background: transparent">
	<SPAN STYLE="background: transparent"><A HREF="helpfile.php?file=report_definitions_16.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>&">16.0 Gestion de programmes&nbsp;:&nbsp;Services fournis</A></SPAN></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_16.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#16.1">16.1 Utilisation</A></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_16.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#16.2">16.2 R&eacute;sultats</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_16.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#16.2.1">16.2.1 Figure 20 : Extrait du rapport&nbsp;:&nbsp;Visites par mois, pour l&rsquo;H&ocirc;pital St. Michel</A></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_16.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#16.3">16.3 D&eacute;finitions importantes</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_16.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#16.3.1">16.3.1 Nombre de visites par mois</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_16.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#16.3.2">16.3.2 Diagnostics nouvellement &eacute;tablis</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_16.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#16.3.3">16.3.3 Diagnostics actifs</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_16.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#16.3.4">16.3.4 Analyses de laboratoire prescrites</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_16.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#16.3.5">16.3.5 Analyses de laboratoire effectu&eacute;s</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_16.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#16.3.6">16.3.6 M&eacute;dicaments prescrits</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_16.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#16.3.7">16.3.7 M&eacute;dicaments dispens&eacute;s</A></P>
	<P STYLE="margin-left: 0.08in; margin-right: 0.08in; margin-bottom: 0in; background: transparent">
	<SPAN STYLE="background: transparent"><A HREF="helpfile.php?file=report_definitions_17.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>&">17.0 Qualit&eacute; des donn&eacute;es&nbsp;:&nbsp;Donn&eacute;es manquantes</A></SPAN></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_17.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#17.1">17.1 Utilisation</A></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_17.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#17.2">17.2 R&eacute;sultats</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_17.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#17.2.1">17.2.1 Figure 21 : En-t&ecirc;te de r&eacute;sultats pour le rapport&nbsp;:&nbsp;Patients sans d&eacute;signation de sexe</A></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_17.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#17.3">17.3 D&eacute;finitions importantes</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_17.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#17.3.1">17.3.1 Patients sans d&eacute;signation de sexe</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_17.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#17.3.2">17.3.2 Patients sans sp&eacute;cification d&rsquo;ann&eacute;e de naissance ou d&rsquo;&acirc;ge</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_17.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#17.3.3">17.3.3 Patients sans no. d&rsquo;&eacute;tablissement</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_17.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#17.3.4">17.3.4 Patients de statut actif avec des fiches de pharmacie compl&eacute;t&eacute;es</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_17.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#17.3.5">17.3.5 Patients de statut actif avec des fiches de laboratoire compl&eacute;t&eacute;es</A></P>
	<P STYLE="margin-left: 0.08in; margin-right: 0.08in; margin-bottom: 0in; background: transparent">
	<SPAN STYLE="background: transparent"><A HREF="helpfile.php?file=report_definitions_18.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>&">18.0 Qualit&eacute; des donn&eacute;es&nbsp;:&nbsp;Donn&eacute;es non-valides</A></SPAN></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_18.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#18.1">18.1 Utilisation</A></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_18.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#18.2">18.2 R&eacute;sultats</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_18.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#18.2.1">18.2.1 Figure 22 : En-t&ecirc;te de r&eacute;sultats pour le rapport&nbsp;:&nbsp;Date de visite ult&eacute;rieure &agrave; la date d'entr&eacute;e des donn&eacute;es</A></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_18.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#18.3">18.3 D&eacute;finitions importantes</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_18.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#18.3.1">18.3.1 Date de visite ult&eacute;rieure &agrave; la date d&rsquo;entr&eacute;e des donn&eacute;es</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_18.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#18.3.2">18.3.2 Mauvaise date de visite</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_18.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#18.3.3">18.3.3 Patients avec activit&eacute; apr&egrave;s discontinuation</A></P>
	<P STYLE="margin-left: 0.08in; margin-right: 0.08in; margin-bottom: 0in; background: transparent">
	<SPAN STYLE="background: transparent"><A HREF="helpfile.php?file=report_definitions_19.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>&">19.0 Qualit&eacute; des donn&eacute;e&nbsp;:&nbsp;&Eacute;purage des donn&eacute;es</A></SPAN></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_19.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#19.1">19.1 Utilisation</A></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_19.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#19.2">19.2 R&eacute;sultats</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_19.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#19.2.1">19.2.1 Figure 23 : En-t&ecirc;te de r&eacute;sultats pour le rapport&nbsp;:&nbsp;Fiches comportant des erreurs</A></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_19.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#19.3">19.3 D&eacute;finitions importantes</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_19.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#19.3.1">19.3.1 &Eacute;ventualit&eacute; de duplication d'enregistrement de patients</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_19.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#19.3.2">19.3.2 Fiches comportant des erreurs (rapport r&eacute;capitulatif)</A></P>
	<P STYLE="margin-left: 0.08in; margin-right: 0.08in; margin-bottom: 0in; background: transparent">
	<SPAN STYLE="background: transparent"><A HREF="helpfile.php?file=report_definitions_20.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>&">20.0 Qualit&eacute; des donn&eacute;es&nbsp;:&nbsp;Processus de gestion des donn&eacute;es</A></SPAN></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_20.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#20.1">20.1 Utilisation</A></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_20.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#20.2">20.2 R&eacute;sultats</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_20.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#20.2.1">20.2.1 Figure 24 : En-t&ecirc;te de r&eacute;sultats pour le rapport&nbsp;:&nbsp;Patients avec uniquement une fiche d'enregistrement</A></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_20.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#20.3">20.3 D&eacute;finitions importantes</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_20.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#20.3.1">20.3.1 Date de visite/Laps de temps avant la saisie des donn&eacute;es</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_20.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#20.3.2">20.3.2 Fiches r&eacute;cemment saisies</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_20.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#20.3.2.1">20.3.2.1 Figure 25 : Param&egrave;tres additionnels sollicit&eacute;s pour le rapport&nbsp;:&nbsp;Fiches r&eacute;cemment saisies</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_20.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#20.3.3">20.3.3 Nombre de fiches saisies la semaine derni&egrave;re</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_20.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#20.3.4">20.3.4 Nombre de fiches saisies le mois dernier</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_20.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#20.3.5">20.3.5 Patients avec uniquement une fiche d'enregistrement</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_20.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#20.3.6">20.3.6 Patients sans fiche de premi&egrave;re visite</A></P>
	<P STYLE="margin-left: 0.08in; margin-right: 0.08in; margin-bottom: 0in; background: transparent">
	<SPAN STYLE="background: transparent"><A HREF="helpfile.php?file=report_definitions_21.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>&">21.0 Qualit&eacute; des donn&eacute;es&nbsp;:&nbsp;Mise &agrave; jour d&rsquo;informations d&eacute;mographiques</A></SPAN></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_21.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#21.1">21.1 Utilisation</A></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_21.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#21.2">21.2 R&eacute;sultats</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_21.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#21.2.1">21.2.1 Figure 26 : Exemple d&rsquo;une partie de rapport&nbsp;:&nbsp;Modification d&rsquo;informations d&eacute;mographiques</A></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_21.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#21.3">21.3 D&eacute;finitions importantes</A></P>
	<P STYLE="margin-left: 0.08in; margin-right: 0.08in; margin-bottom: 0in; background: transparent">
	<SPAN STYLE="background: transparent"><A HREF="helpfile.php?file=report_definitions_22.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>&">22.0 Informations r&eacute;capitulatives d'&eacute;tablissements</A></SPAN></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_22.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#22.1">22.1 Utilisation</A></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_22.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#22.2">22.2 R&eacute;sultats</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_22.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#22.2.1">22.2.1 Figure 27 : Exemple d&rsquo;une partie du rapport&nbsp;:&nbsp;Informations r&eacute;capitulatives d&rsquo;&eacute;tablissement, pour l&rsquo;H&ocirc;pital St. Michel</A></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_22.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#22.3">22.3 D&eacute;finitions importantes</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_22.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#22.3.1">22.3.1 Version</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_22.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#22.3.2">22.3.2 Serveur local</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_22.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#22.3.3">22.3.3 Date de saisie la plus r&eacute;cente</A></P>
	<P STYLE="margin-left: 0.08in; margin-right: 0.08in; margin-bottom: 0in; background: transparent">
	<SPAN STYLE="background: transparent"><A HREF="helpfile.php?file=report_definitions_23.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>&">23.0 R&eacute;sum&eacute; du dossier m&eacute;dical</A></SPAN></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_23.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#23.1">23.1 Utilisation</A></P>
	<P STYLE="margin-left: 0.28in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_23.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#23.2">23.2 R&eacute;sultats</A></P>
	<P STYLE="margin-left: 0.48in; margin-right: 0.08in; margin-bottom: 0in">
	<A HREF="helpfile.php?file=report_definitions_23.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>#23.2.1">23.2.1 Figure 28 : Exemple d&rsquo;une partie du rapport&nbsp;:&nbsp;R&eacute;sum&eacute; du dossierm&eacute;dical</A></P>
	<P STYLE="font-family: Arial, sans-serif; font-size: 12pt; so-language: en-US; margin-bottom: 0in; font-weight: medium"><BR>
	</P>
</TD></TR>
<TR>
<TD WIDTH="930">
 <TABLE BGCOLOR="#DDDDDD" WIDTH="100%" ALIGN="CENTER">
  <TR>
   <TD ALIGN="CENTER" WIDTH="25%"><A CLASS="pages" HREF="helpfile.php?file=report_definitions_1.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>&"><< 1.0 Table des mati&egrave;res <<</A></TD>
   <TD ALIGN="CENTER" WIDTH="25%">&nbsp;</TD>
   <TD ALIGN="CENTER" WIDTH="25%"><A CLASS="pages" HREF="#_top"> ^ Retour en haut de la page ^</A></TD>
   <TD ALIGN="CENTER" WIDTH="25%"><A CLASS="pages" HREF="helpfile.php?file=report_definitions_2.0&extension=php&titleen=EMR%20Report%20Definitions&titlefr=Rapport%20de%20d%e9finition%20EMR&lang=<?php echo $lang;?>&">> 2.0 R&eacute;sum&eacute; ></A></TD>
  </TR>
 </TABLE>
</TD></TR>
</TABLE>

