insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71634,'bonneSanteApparente','bonneSanteApparente','Bonne Sante Apparente','en','0','2015-11-16');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71634,'bonneSanteApparente','bonneSanteApparente','Bonne Sante Apparente','fr','0','2015-11-16');

insert into concept (concept_id,retired,short_name,description,form_text,datatype_id,class_id,is_set,creator,date_created) values ('71634','0','bonneSanteApparente','Bonne Sante Apparente',' ','10','4','0','1','2015-11-16');
