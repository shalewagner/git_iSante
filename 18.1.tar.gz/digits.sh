#!/bin/sh

mysql -A -u cirgadmin -pViebuetai7 itech  < /var/www/isante/support/schema-functions.sql
