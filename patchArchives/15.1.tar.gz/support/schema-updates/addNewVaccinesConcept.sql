insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71610,'rotavirusDtD1','rotavirusDtD1','Rotavirus','en','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71610,'rotavirusDtD1','rotavirusDtD1','Rotavirus','fr','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71611,'rotavirusDtD2','rotavirusDtD2','Rotavirus','en','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71611,'rotavirusDtD2','rotavirusDtD2','Rotavirus','fr','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71612,'varicelDtD1','varicelDtD1','Varicelle','en','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71612,'varicelDtD1','varicelDtD1','Varicelle','fr','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71613,'varicelDtD2','varicelDtD2','Varicelle','en','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71613,'varicelDtD2','varicelDtD2','Varicelle','fr','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71614,'typhimviDtD1','typhimviDtD1','Typhimvi','en','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71614,'typhimviDtD1','typhimviDtD1','Typhimvi','fr','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71615,'typhimviDtD2','typhimviDtD2','Typhimvi','en','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71615,'typhimviDtD2','typhimviDtD2','Typhimvi','fr','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71616,'pneumocoqueDtD1','pneumocoqueDtD1','Pneumocoque','en','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71616,'pneumocoqueDtD1','pneumocoqueDtD1','Pneumocoque','fr','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71617,'pneumocoqueDtD2','pneumocoqueDtD2','Pneumocoque','en','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71617,'pneumocoqueDtD2','pneumocoqueDtD2','Pneumocoque','fr','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71618,'pneumocoqueDtD3','pneumocoqueDtD3','Pneumocoque','en','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71618,'pneumocoqueDtD3','pneumocoqueDtD3','Pneumocoque','fr','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71619,'hepatiteADtD1','hepatiteADtD1','Hepatite A','en','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71619,'hepatiteADtD1','hepatiteADtD1','Hepatite A','fr','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71620,'hepatiteADtD2','hepatiteADtD2','Hepatite A','en','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71620,'hepatiteADtD2','hepatiteADtD2','Hepatite A','fr','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71621,'menengoAcDtD1','menengoAcDtD1','Menengo AC','en','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71621,'menengoAcDtD1','menengoAcDtD1','Menengo AC','fr','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71622,'menengoAcDtD2','menengoAcDtD2','Menengo AC','en','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71622,'menengoAcDtD2','menengoAcDtD2','Menengo AC','fr','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71623,'choleraDtD1','choleraDtD1','Cholera','en','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71623,'choleraDtD1','choleraDtD1','Cholera','fr','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71624,'choleraDtD2','choleraDtD2','Cholera','en','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71624,'choleraDtD2','choleraDtD2','Cholera','fr','1','2014-08-18');


insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71625,'varicelDose','varicelDose','varicelDose','fr','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71625,'varicelDose','varicelDose','varicelDose','en','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71626,'rotavirusDose','rotavirusDose','rotavirusDose','fr','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71626,'rotavirusDose','rotavirusDose','rotavirusDose','en','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71627,'typhimviDose','typhimviDose','typhimviDose','fr','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71627,'typhimviDose','typhimviDose','typhimviDose','en','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71628,'pneumocoqueDose','pneumocoqueDose','pneumocoqueDose','fr','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71628,'pneumocoqueDose','pneumocoqueDose','pneumocoqueDose','en','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71629,'hepatiteADose','hepatiteADose','hepatiteADose','fr','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71629,'hepatiteADose','hepatiteADose','hepatiteADose','en','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71630,'menengoAcDose','menengoAcDose','menengoAcDose','fr','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71630,'menengoAcDose','menengoAcDose','menengoAcDose','en','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71631,'choleraDose','choleraDose','choleraDose','fr','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71631,'choleraDose','choleraDose','choleraDose','en','1','2014-08-18');



insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71632,'pneumocoqueDtIncom','pneumocoqueDtIncom','pneumocoque Unknown','en','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71632,'pneumocoqueDtIncom','pneumocoqueDtIncom','pneumocoque Unknown','fr','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71633,'pneumocoqueNeverRecd','pneumocoqueNeverRecd','pneumocoque Never','en','1','2014-08-18');
insert into concept_name (concept_id,name,short_name,description,locale,creator,date_created) values (71633,'pneumocoqueNeverRecd','pneumocoqueNeverRecd','pneumocoque Never','en','1','2014-08-18');



insert into concept (concept_id,retired,short_name,description,form_text,datatype_id,class_id,is_set,creator,date_created) values ('71610','0','rotavirusDtD1','Rotavirus','Rotavirus','8','5','0','1','2014-08-18');
insert into concept (concept_id,retired,short_name,description,form_text,datatype_id,class_id,is_set,creator,date_created) values ('71611','0','rotavirusDtD2','Rotavirus','Rotavirus','8','5','0','1','2014-08-18');
insert into concept (concept_id,retired,short_name,description,form_text,datatype_id,class_id,is_set,creator,date_created) values ('71612','0','varicelDtD1','Varicelle','Varicelle','8','5','0','1','2014-08-18');
insert into concept (concept_id,retired,short_name,description,form_text,datatype_id,class_id,is_set,creator,date_created) values ('71613','0','varicelDtD2','Varicelle','Varicelle','8','5','0','1','2014-08-18');
insert into concept (concept_id,retired,short_name,description,form_text,datatype_id,class_id,is_set,creator,date_created) values ('71614','0','typhimviDtD1','Typhimvi','Typhimvi','8','5','0','1','2014-08-18');
insert into concept (concept_id,retired,short_name,description,form_text,datatype_id,class_id,is_set,creator,date_created) values ('71615','0','typhimviDtD2','Typhimvi','Typhimvi','8','5','0','1','2014-08-18');
insert into concept (concept_id,retired,short_name,description,form_text,datatype_id,class_id,is_set,creator,date_created) values ('71616','0','pneumocoqueDtD1','Pneumocoque','Pneumocoque','8','5','0','1','2014-08-18');
insert into concept (concept_id,retired,short_name,description,form_text,datatype_id,class_id,is_set,creator,date_created) values ('71617','0','pneumocoqueDtD2','Pneumocoque','Pneumocoque','8','5','0','1','2014-08-18');
insert into concept (concept_id,retired,short_name,description,form_text,datatype_id,class_id,is_set,creator,date_created) values ('71618','0','pneumocoqueDtD3','Pneumocoque','Pneumocoque','8','5','0','1','2014-08-18');
insert into concept (concept_id,retired,short_name,description,form_text,datatype_id,class_id,is_set,creator,date_created) values ('71619','0','hepatiteADtD1','Hepatite A','Hepatite A','8','5','0','1','2014-08-18');
insert into concept (concept_id,retired,short_name,description,form_text,datatype_id,class_id,is_set,creator,date_created) values ('71620','0','hepatiteADtD2','Hepatite A','Hepatite A','8','5','0','1','2014-08-18');
insert into concept (concept_id,retired,short_name,description,form_text,datatype_id,class_id,is_set,creator,date_created) values ('71621','0','menengoAcDtD1','Menengo AC','Menengo AC','8','5','0','1','2014-08-18');
insert into concept (concept_id,retired,short_name,description,form_text,datatype_id,class_id,is_set,creator,date_created) values ('71622','0','menengoAcDtD2','Menengo AC','Menengo AC','8','5','0','1','2014-08-18');
insert into concept (concept_id,retired,short_name,description,form_text,datatype_id,class_id,is_set,creator,date_created) values ('71623','0','choleraDtD1','Cholera','Cholera','8','5','0','1','2014-08-18');
insert into concept (concept_id,retired,short_name,description,form_text,datatype_id,class_id,is_set,creator,date_created) values ('71624','0','choleraDtD2','Cholera','Cholera','8','5','0','1','2014-08-18');


insert into concept (concept_id,retired,short_name,description,form_text,datatype_id,class_id,is_set,creator,date_created) values ('71625','0','varicelDose','varicelDose','varicelDose','3','5','0','1','2014-08-18');
insert into concept (concept_id,retired,short_name,description,form_text,datatype_id,class_id,is_set,creator,date_created) values ('71626','0','rotavirusDose','rotavirusDose','rotavirusDose','3','5','0','1','2014-08-18');
insert into concept (concept_id,retired,short_name,description,form_text,datatype_id,class_id,is_set,creator,date_created) values ('71627','0','typhimviDose','typhimviDose','typhimviDose','3','5','0','1','2014-08-18');
insert into concept (concept_id,retired,short_name,description,form_text,datatype_id,class_id,is_set,creator,date_created) values ('71628','0','pneumocoqueDose','pneumocoqueDose','pneumocoqueDose','3','5','0','1','2014-08-18');
insert into concept (concept_id,retired,short_name,description,form_text,datatype_id,class_id,is_set,creator,date_created) values ('71629','0','hepatiteADose','hepatiteADose','hepatiteADose','3','5','0','1','2014-08-18');
insert into concept (concept_id,retired,short_name,description,form_text,datatype_id,class_id,is_set,creator,date_created) values ('71630','0','menengoAcDose','menengoAcDose','menengoAcDose','3','5','0','1','2014-08-18');
insert into concept (concept_id,retired,short_name,description,form_text,datatype_id,class_id,is_set,creator,date_created) values ('71631','0','choleraDose','choleraDose','choleraDose','3','5','0','1','2014-08-18');
insert into concept (concept_id,retired,short_name,description,form_text,datatype_id,class_id,is_set,creator,date_created) values ('71632','0','pneumocoqueDtIncom','pneumocoqueDtIncom','pneumocoque Unknown','3','5','0','1','2014-08-18');
insert into concept (concept_id,retired,short_name,description,form_text,datatype_id,class_id,is_set,creator,date_created) values ('71633','0','pneumocoqueNeverRecd','pneumocoqueNeverRecd','pneumocoque Never','3','5','0','1','2014-08-18');
