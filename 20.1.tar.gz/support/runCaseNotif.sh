#!/bin/sh -vx

php runCaseNotif.php startSitecode=11100 endSitecode=11100
mv /var/backups/itech/case-notifications/queue/newFile.zip /var/backups/itech/case-notifications/queue/run0.zip
php runCaseNotif.php startSitecode=11106 endSitecode=11127
mv /var/backups/itech/case-notifications/queue/newFile.zip /var/backups/itech/case-notifications/queue/run16.zip
php runCaseNotif.php startSitecode=11134 endSitecode=11158
mv /var/backups/itech/case-notifications/queue/newFile.zip /var/backups/itech/case-notifications/queue/run17.zip
php runCaseNotif.php startSitecode=11164 endSitecode=11217
mv /var/backups/itech/case-notifications/queue/newFile.zip /var/backups/itech/case-notifications/queue/run18.zip
php runCaseNotif.php startSitecode=11219 endSitecode=11229
mv /var/backups/itech/case-notifications/queue/newFile.zip /var/backups/itech/case-notifications/queue/run19.zip
php runCaseNotif.php startSitecode=11230 endSitecode=11405
mv /var/backups/itech/case-notifications/queue/newFile.zip /var/backups/itech/case-notifications/queue/run1.zip
php runCaseNotif.php startSitecode=11412 endSitecode=12201
mv /var/backups/itech/case-notifications/queue/newFile.zip /var/backups/itech/case-notifications/queue/run2.zip
php runCaseNotif.php startSitecode=13103 endSitecode=15103
mv /var/backups/itech/case-notifications/queue/newFile.zip /var/backups/itech/case-notifications/queue/run3.zip
php runCaseNotif.php startSitecode=21100 endSitecode=23301
mv /var/backups/itech/case-notifications/queue/newFile.zip /var/backups/itech/case-notifications/queue/run4.zip
php runCaseNotif.php startSitecode=31100 endSitecode=31100
mv /var/backups/itech/case-notifications/queue/newFile.zip /var/backups/itech/case-notifications/queue/run5.zip
php runCaseNotif.php startSitecode=31101 endSitecode=32205
mv /var/backups/itech/case-notifications/queue/newFile.zip /var/backups/itech/case-notifications/queue/run6.zip
php runCaseNotif.php startSitecode=32207 endSitecode=35101
mv /var/backups/itech/case-notifications/queue/newFile.zip /var/backups/itech/case-notifications/queue/run7.zip
php runCaseNotif.php startSitecode=35201 endSitecode=41100
mv /var/backups/itech/case-notifications/queue/newFile.zip /var/backups/itech/case-notifications/queue/run8.zip
php runCaseNotif.php startSitecode=41201 endSitecode=51204
mv /var/backups/itech/case-notifications/queue/newFile.zip /var/backups/itech/case-notifications/queue/run9.zip
php runCaseNotif.php startSitecode=52101 endSitecode=61120
mv /var/backups/itech/case-notifications/queue/newFile.zip /var/backups/itech/case-notifications/queue/run10.zip
php runCaseNotif.php startSitecode=71100 endSitecode=71104
mv /var/backups/itech/case-notifications/queue/newFile.zip /var/backups/itech/case-notifications/queue/run11.zip
php runCaseNotif.php startSitecode=71106 endSitecode=81100
mv /var/backups/itech/case-notifications/queue/newFile.zip /var/backups/itech/case-notifications/queue/run12.zip
php runCaseNotif.php startSitecode=81101 endSitecode=84111
mv /var/backups/itech/case-notifications/queue/newFile.zip /var/backups/itech/case-notifications/queue/run13.zip
php runCaseNotif.php startSitecode=91100 endSitecode=91114
mv /var/backups/itech/case-notifications/queue/newFile.zip /var/backups/itech/case-notifications/queue/run14.zip
php runCaseNotif.php startSitecode=93301 endSitecode=95698
mv /var/backups/itech/case-notifications/queue/newFile.zip /var/backups/itech/case-notifications/queue/run15.zip
